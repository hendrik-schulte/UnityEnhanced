### Installation

If you want to use asmdef files, copy from the respective folder:

#### RAW

Only UnityEnhanced.

#### Photon

UnityEnhanced with reference to Photon Unity Networking assembly.